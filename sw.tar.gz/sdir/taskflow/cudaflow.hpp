#pragma once

#define TF_CUDA 1

#include <cuda.h>
#include "cuda/flow_builder.hpp"

namespace tf { namespace cuda {

}}  // end of namespace tf::cuda ----------------------------------------------
